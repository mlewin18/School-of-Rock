School of Rock uses only built in python libraries.

For the program to be fully functional the following files must be present:
ascii.py
instructions.py
printing.py
School_of_rock.py
movements.txt
senses.txt

To run the full program access School_of_rock.py through command line.

Tip: The program looks best in full screen.